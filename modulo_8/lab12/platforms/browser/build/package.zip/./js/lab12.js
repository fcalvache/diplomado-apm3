angular.module('lab12', ['ngCordova'])

.controller('lab12Controller', function($scope, $cordovaDialogs){

	console.log('load lab12Controller');

	$scope.active_alert =function(){
		$cordovaDialogs.alert('nCordova', 'Hola!', 'Aceptar')
	    .then(function() {
	       $scope.lab="lab12";
	    });
	};
	$scope.active_confirm = function(){

		 $cordovaDialogs.confirm('Oye que vas a utilizar', 'Confirmar', ['Aceptar','Cancelar'])
		    .then(function(buttonIndex) {
		      // no button = 0, 'OK' = 1, 'Cancel' = 2
		      var btnIndex = buttonIndex;

		      if (btnIndex === 0) {

		      } 

		      else if(btnIndex===1){
		      	$scope.boton="El botón es Aceptar";
		      	console.log('El botón es Aceptar');
		      }

		      else {
		      	$scope.boton="El botón es Cancelar";
		      	console.log('El botón es Cancelar');
		      }

    	});
	};
});